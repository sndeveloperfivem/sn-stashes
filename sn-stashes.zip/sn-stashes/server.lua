local ESX, QBCore = nil, nil

local function SendNotificationInternal(target, msg, type)
    if Config.Framework == 'ESX' then
        TriggerClientEvent('esx:showNotification', target, msg)
    elseif Config.Framework == 'QB' then
        TriggerClientEvent('QBCore:Notify', target, msg, type)
    end
end

local function RegisterFrameworkItems()
    if Config.Framework == 'ESX' then
        ESX.RegisterCommand(Config.Command, Config.AdminGroup, function(xPlayer)
            xPlayer.triggerEvent('sn-stashes:openUI')
        end, false)
        
        ESX.RegisterServerCallback('sn-stashes:getStashes', function(source, cb)
            MySQL.query('SELECT * FROM ox_stashes', {}, function(stashes)
                cb(stashes)
            end)
        end)
    elseif Config.Framework == 'QB' then
        QBCore.Commands.Add(Config.Command, "Admin Stash Manager", {}, false, function(source)
            TriggerClientEvent('sn-stashes:openUI', source)
        end, Config.AdminGroup)

        QBCore.Functions.CreateCallback('sn-stashes:getStashes', function(source, cb)
            MySQL.query('SELECT * FROM ox_stashes', {}, function(stashes)
                cb(stashes)
            end)
        end)
    end
end

CreateThread(function()
    local success = false
    while not success do
        if Config.Framework == 'AUTO' or Config.Framework == 'ESX' then
            if GetResourceState('es_extended') == 'started' then
                ESX = exports["es_extended"]:getSharedObject()
                if ESX then 
                    Config.Framework = 'ESX'
                    success = true 
                end
            end
        end
        if not success and (Config.Framework == 'AUTO' or Config.Framework == 'QB') then
            if GetResourceState('qb-core') == 'started' then
                QBCore = exports['qb-core']:GetCoreObject()
                if QBCore then 
                    Config.Framework = 'QB'
                    success = true 
                end
            end
        end
        if success then
            RegisterFrameworkItems()
            print('^2[StashManage] Initialized for ' .. Config.Framework .. '^7')
        else
            Wait(1000)
        end
    end
end)

local function RegisterStashInInventory(id, label, slots, weight, owner, groups, coords)
    local finalGroups = (groups and next(groups) ~= nil) and groups or nil
    
    exports.ox_inventory:RegisterStash(id, label, slots, weight, owner, finalGroups, coords)
end

RegisterNetEvent('sn-stashes:saveStash')
AddEventHandler('sn-stashes:saveStash', function(data)
    local src = source
    local hasPerm = false

    if Config.Framework == 'ESX' and ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer and xPlayer.getGroup() == Config.AdminGroup then hasPerm = true end
    elseif Config.Framework == 'QB' and QBCore then
        hasPerm = QBCore.Functions.HasPermission(src, Config.AdminGroup)
    end

    if not hasPerm then return end

    local finalOwner = data.owner
    if data.owner == "true" then finalOwner = true 
    elseif data.owner == "false" then finalOwner = false 
    elseif data.owner == "" then finalOwner = nil end

    local dbGroups = (data.groups and next(data.groups) ~= nil) and data.groups or {}

    MySQL.query([[
        INSERT INTO ox_stashes (id, label, slots, weight, owner, groups, coords)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
        label = VALUES(label), slots = VALUES(slots), weight = VALUES(weight), 
        owner = VALUES(owner), groups = VALUES(groups), coords = VALUES(coords)
    ]], {
        data.id, data.label, data.slots, data.weight, finalOwner, 
        json.encode(dbGroups), json.encode(data.coords)
    }, function()
        RegisterStashInInventory(data.id, data.label, data.slots, data.weight, finalOwner, dbGroups, data.coords)
        
        TriggerClientEvent('sn-stashes:refreshTargets', -1)
        
        if Config.Framework == 'ESX' then
            TriggerClientEvent('esx:showNotification', src, "Stash guardado y configurado.")
        else
            TriggerClientEvent('QBCore:Notify', src, "Stash guardado y configurado.", "success")
        end
    end)
end)

RegisterNetEvent('sn-stashes:deleteStash')
AddEventHandler('sn-stashes:deleteStash', function(stashId)
    local src = source
    local hasPerm = false

    if Config.Framework == 'ESX' and ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer and xPlayer.getGroup() == Config.AdminGroup then hasPerm = true end
    elseif Config.Framework == 'QB' and QBCore then
        hasPerm = QBCore.Functions.HasPermission(src, Config.AdminGroup)
    end

    if not hasPerm then return end

    MySQL.update('DELETE FROM ox_stashes WHERE id = ?', {stashId}, function()
        TriggerClientEvent('sn-stashes:refreshTargets', -1)
        SendNotificationInternal(src, "Stash eliminado.", "error")
    end)
end)

local function InitStashes()
    MySQL.query('SELECT * FROM ox_stashes', {}, function(stashes)
        if stashes then
            for i=1, #stashes do
                local s = stashes[i]
                local owner = s.owner
                if owner == "true" then owner = true elseif owner == "false" then owner = false end
                
                local groups = json.decode(s.groups)
                local coords = json.decode(s.coords)
                
                RegisterStashInInventory(s.id, s.label, s.slots, s.weight, owner, groups, coords)
            end
            print('^2[StashManage] ' .. #stashes .. ' stashes cargados.^7')
            TriggerClientEvent('sn-stashes:refreshTargets', -1)
        end
    end)
end
MySQL.ready(InitStashes)