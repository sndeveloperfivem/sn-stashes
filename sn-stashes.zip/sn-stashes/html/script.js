let currentCoords = null;
let editing = false;
let allStashes = [];

window.addEventListener('message', function(event) {
    const data = event.data;
    if (data.action === "show") {
        document.getElementById('container').style.display = 'flex';
        allStashes = data.stashes || [];
        renderTable(allStashes);
        if (data.restoredData) {
            openModal();
            restoreForm(data.restoredData);
        }
    }
});

function renderTable(stashes) {
    const tbody = document.getElementById('stash-list-body');
    tbody.innerHTML = '';

    if (!stashes || stashes.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; padding: 40px; color: #64748b;">No hay inventarios registrados</td></tr>`;
        return;
    }

    const groups = {};
    stashes.forEach(s => {
        let jobName = "OTROS";
        try {
            const parsedGroups = typeof s.groups === 'string' ? JSON.parse(s.groups) : s.groups;
            if (parsedGroups && typeof parsedGroups === 'object') {
                const keys = Object.keys(parsedGroups);
                if (keys.length > 0) jobName = keys[0].toUpperCase();
            }
        } catch (e) { jobName = "OTROS"; }
        
        if (!groups[jobName]) groups[jobName] = [];
        groups[jobName].push(s);
    });

    Object.keys(groups).sort().forEach(job => {
        const categoryRow = document.createElement('tr');
        categoryRow.className = "job-category-separator";
        categoryRow.innerHTML = `<td colspan="4"><i class="fas fa-briefcase"></i> ${job}</td>`;
        tbody.appendChild(categoryRow);

        groups[job].forEach(s => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><code>${s.id}</code></td>
                <td>${s.label}</td>
                <td style="color: #64748b; font-size: 12px;">
                    <i class="fas fa-weight-hanging"></i> ${(s.weight / 1000).toFixed(1)}kg | 
                    <i class="fas fa-th"></i> ${s.slots} slots
                </td>
                <td style="text-align: center;">
                    <button class="btn-edit" onclick='loadStashToEdit(${JSON.stringify(s)})'>
                        <i class="fas fa-cog"></i> CONFIGURAR
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    });
}

function loadStashToEdit(stash) {
    editing = true;
    openModal();
    document.getElementById('form-title').innerText = "Editar Inventario";
    document.getElementById('s-id').value = stash.id;
    document.getElementById('s-id').disabled = true;
    document.getElementById('s-label').value = stash.label;
    document.getElementById('s-slots').value = stash.slots;
    document.getElementById('s-weight').value = stash.weight;
    document.getElementById('s-owner').value = stash.owner || "false";
    
    let groups = null;
    try {
        groups = typeof stash.groups === 'string' ? JSON.parse(stash.groups) : stash.groups;
    } catch(e) { groups = null; }

    if (groups && typeof groups === 'object') {
        const jobName = Object.keys(groups)[0];
        document.getElementById('s-group-name').value = jobName || "";
        document.getElementById('s-group-grade').value = groups[jobName] || 0;
    } else {
        document.getElementById('s-group-name').value = "";
        document.getElementById('s-group-grade').value = "";
    }

    try {
        currentCoords = typeof stash.coords === 'string' ? JSON.parse(stash.coords) : stash.coords;
        if (currentCoords && currentCoords.x) {
            document.getElementById('coords-display').innerText = `X: ${currentCoords.x.toFixed(2)} | Y: ${currentCoords.y.toFixed(2)}`;
            document.getElementById('coords-display').style.color = "#2563eb";
        }
    } catch(e) { currentCoords = null; }
    
    document.getElementById('btn-delete').style.display = 'block';
    document.getElementById('btn-save').innerText = "ACTUALIZAR DATOS";
}

function restoreForm(data) {
    document.getElementById('s-id').value = data.id || "";
    document.getElementById('s-label').value = data.label || "";
    document.getElementById('s-slots').value = data.slots || "";
    document.getElementById('s-weight').value = data.weight || "";
    document.getElementById('s-group-name').value = data.jobName || "";
    document.getElementById('s-group-grade').value = data.jobGrade || "";
    document.getElementById('s-owner').value = data.owner || "false";
    
    if (data.coords && typeof data.coords.x !== 'undefined') {
        currentCoords = data.coords;
        document.getElementById('coords-display').innerText = `X: ${data.coords.x.toFixed(2)} | Y: ${data.coords.y.toFixed(2)}`;
        document.getElementById('coords-display').style.color = "#2563eb";
    } else {
        document.getElementById('coords-display').innerText = "No seleccionadas";
        document.getElementById('coords-display').style.color = "#64748b";
    }
}

document.getElementById('btn-coords').onclick = () => {
    const dataToSend = {
        id: document.getElementById('s-id').value,
        label: document.getElementById('s-label').value,
        slots: document.getElementById('s-slots').value,
        weight: document.getElementById('s-weight').value,
        jobName: document.getElementById('s-group-name').value,
        jobGrade: document.getElementById('s-group-grade').value,
        owner: document.getElementById('s-owner').value
    };
    document.getElementById('modal-overlay').style.display = 'none';
    document.getElementById('container').style.display = 'none';
    fetch(`https://${GetParentResourceName()}/startSelectingCoords`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dataToSend)
    });
};

document.getElementById('btn-save').onclick = () => {
    const sId = document.getElementById('s-id').value.trim();
    if (!sId || !currentCoords) return;
    const jobName = document.getElementById('s-group-name').value.trim();
    const jobGrade = document.getElementById('s-group-grade').value;
    const ownerVal = document.getElementById('s-owner').value.trim();
    let groups = (jobName !== "") ? { [jobName]: parseInt(jobGrade) || 0 } : null;
    fetch(`https://${GetParentResourceName()}/saveStash`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            id: sId,
            label: document.getElementById('s-label').value || sId,
            slots: parseInt(document.getElementById('s-slots').value) || 50,
            weight: parseInt(document.getElementById('s-weight').value) || 100000,
            coords: currentCoords,
            groups: groups,
            owner: ownerVal
        })
    });
    closeUI();
};

document.getElementById('btn-save').onclick = () => {
    const sId = document.getElementById('s-id').value.trim();
    if (!sId || !currentCoords) return;
    
    const jobName = document.getElementById('s-group-name').value.trim();
    const jobGrade = document.getElementById('s-group-grade').value;
    const ownerVal = document.getElementById('s-owner').value.trim();
    

    let groups = (jobName !== "") ? { [jobName]: parseInt(jobGrade) || 0 } : {};
    
    fetch(`https://${GetParentResourceName()}/saveStash`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            id: sId,
            label: document.getElementById('s-label').value || sId,
            slots: parseInt(document.getElementById('s-slots').value) || 50,
            weight: parseInt(document.getElementById('s-weight').value) || 100000,
            coords: currentCoords,
            groups: groups,
            owner: ownerVal
        })
    });
    closeUI();
};

document.getElementById('btn-new-view').onclick = () => {
    editing = false;
    openModal();
    document.getElementById('form-title').innerText = "Nuevo Registro";
    document.getElementById('s-id').disabled = false;
    document.getElementById('btn-delete').style.display = 'none';
    document.getElementById('btn-save').innerText = "CREAR REGISTRO";
};

document.getElementById('searchInput').addEventListener('keyup', function(e) {
    const term = e.target.value.toLowerCase();
    const filtered = allStashes.filter(s => 
        s.id.toLowerCase().includes(term) || s.label.toLowerCase().includes(term)
    );
    renderTable(filtered);
});

function openModal() { document.getElementById('modal-overlay').style.display = 'flex'; }
function closeModal() { 
    document.getElementById('modal-overlay').style.display = 'none'; 
    clearInputs(); 
}

function clearInputs() {
    document.querySelectorAll('.modal-content input').forEach(i => { i.value = ""; i.disabled = false; });
    document.getElementById('coords-display').innerText = "No seleccionadas";
    document.getElementById('coords-display').style.color = "#64748b";
    document.getElementById('s-owner').value = "false";
    currentCoords = null;
}

function closeUI() {
    document.getElementById('container').style.display = 'none';
    closeModal();
    fetch(`https://${GetParentResourceName()}/hideUI`, { method: 'POST' });
}

document.querySelectorAll('.close-modal').forEach(btn => btn.onclick = closeModal);
document.getElementById('close-btn').onclick = closeUI;

window.addEventListener('keydown', (e) => {
    if (e.key === "Escape") {
        if (document.getElementById('modal-overlay').style.display === 'flex') {
            closeModal();
        } else {
            closeUI();
        }
    }
});