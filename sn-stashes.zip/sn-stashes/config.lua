Config = {}

-- 'ESX', 'QB' o 'AUTO'
Config.Framework = 'AUTO' 

Config.Command = 'stashesmanage'
Config.AdminGroup = 'admin' 

function SendNotification(msg, type)
    if IsDuplicityVersion() then
        if Config.Framework == 'ESX' then
            TriggerClientEvent('esx:showNotification', source, msg)
        elseif Config.Framework == 'QB' then
            TriggerClientEvent('QBCore:Notify', source, msg, type)
        end
    end
end