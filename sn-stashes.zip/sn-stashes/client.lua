local ESX, QBCore = nil, nil
local uiOpen = false
local isSelectingCoords = false
local createdTargets = {}
local tempFormData = nil

CreateThread(function()
    if Config.Framework == 'AUTO' or Config.Framework == 'ESX' then
        pcall(function() ESX = exports["es_extended"]:getSharedObject() end)
        if ESX then Config.Framework = 'ESX' end
    end
    if (Config.Framework == 'AUTO' and not ESX) or Config.Framework == 'QB' then
        pcall(function() QBCore = exports['qb-core']:GetCoreObject() end)
        if QBCore then Config.Framework = 'QB' end
    end
end)

local function RotationToDirection(rotation)
    local adjustedRotation = {
        x = (math.pi / 180) * rotation.x,
        y = (math.pi / 180) * rotation.y,
        z = (math.pi / 180) * rotation.z
    }
    return {
        x = -math.sin(adjustedRotation.z) * math.abs(math.cos(adjustedRotation.x)),
        y = math.cos(adjustedRotation.z) * math.abs(math.cos(adjustedRotation.x)),
        z = math.sin(adjustedRotation.x)
    }
end

local function RayCastGamePlayCamera(distance)
    local cameraRotation = GetGameplayCamRot()
    local cameraCoord = GetGameplayCamCoord()
    local direction = RotationToDirection(cameraRotation)
    local destination = {
        x = cameraCoord.x + direction.x * distance,
        y = cameraCoord.y + direction.y * distance,
        z = cameraCoord.z + direction.z * distance
    }
    local a, b, c, d, e = GetShapeTestResult(StartShapeTestRay(cameraCoord.x, cameraCoord.y, cameraCoord.z, destination.x, destination.y, destination.z, -1, PlayerPedId(), 0))
    return b, c, e
end

local function TriggerCallback(name, cb, ...)
    if Config.Framework == 'ESX' then
        ESX.TriggerServerCallback(name, cb, ...)
    else
        QBCore.Functions.TriggerCallback(name, cb, ...)
    end
end

local function RefreshStashTargets()
    for _, targetId in ipairs(createdTargets) do
        exports.ox_target:removeZone(targetId)
    end
    createdTargets = {}

    TriggerCallback('sn-stashes:getStashes', function(stashes)
        if not stashes then return end
        
        for _, s in ipairs(stashes) do
            local coords = type(s.coords) == "string" and json.decode(s.coords) or s.coords
            local groups = type(s.groups) == "string" and json.decode(s.groups) or s.groups
            
            if groups == nil or (type(groups) == "table" and next(groups) == nil) then 
                groups = nil 
            end

            if coords and coords.x then
                local targetId = exports.ox_target:addSphereZone({
                    coords = vec3(coords.x, coords.y, coords.z),
                    radius = 0.5,
                    debug = false,
                    options = {{
                        name = 'stash_'..s.id,
                        icon = 'fa-solid fa-box-open',
                        label = 'Abrir ' .. s.label,
                        groups = groups,
                        onSelect = function() 
                            exports.ox_inventory:openInventory('stash', s.id) 
                        end
                    }}
                })
                table.insert(createdTargets, targetId)
            end
        end
    end)
end

RegisterNetEvent('sn-stashes:openUI')
AddEventHandler('sn-stashes:openUI', function(restoredData)
    TriggerCallback('sn-stashes:getStashes', function(stashes)
        uiOpen = true
        SetNuiFocus(true, true)
        SendNUIMessage({ 
            action = "show", 
            stashes = stashes,
            restoredData = restoredData 
        })
    end)
end)

CreateThread(function()
    while true do
        local sleep = 1000
        if isSelectingCoords then
            sleep = 0
            local hit, coords, entity = RayCastGamePlayCamera(20.0)
            if hit then
                DrawMarker(28, coords.x, coords.y, coords.z, 0, 0, 0, 0, 0, 0, 0.2, 0.2, 0.2, 0, 255, 0, 150, false, true, 2, nil, nil, false)
                if IsControlJustPressed(0, 38) then
                    isSelectingCoords = false
                    tempFormData.coords = {x = coords.x, y = coords.y, z = coords.z}
                    TriggerEvent('sn-stashes:openUI', tempFormData)
                end
            end
            if IsControlJustPressed(0, 177) then
                isSelectingCoords = false
                TriggerEvent('sn-stashes:openUI', tempFormData)
            end
        end
        Wait(sleep)
    end
end)

RegisterNUICallback('startSelectingCoords', function(data, cb)
    tempFormData = data
    SetNuiFocus(false, false)
    uiOpen = false
    isSelectingCoords = true
    cb('ok')
end)

RegisterNUICallback('saveStash', function(data, cb)
    TriggerServerEvent('sn-stashes:saveStash', data)
    cb('ok')
end)

RegisterNUICallback('deleteStash', function(data, cb)
    TriggerServerEvent('sn-stashes:deleteStash', data.id)
    cb('ok')
end)

RegisterNUICallback('hideUI', function(data, cb)
    SetNuiFocus(false, false)
    uiOpen = false
    cb('ok')
end)

RegisterNetEvent('sn-stashes:refreshTargets', RefreshStashTargets)

CreateThread(function()
    Wait(2000)
    RefreshStashTargets()
end)